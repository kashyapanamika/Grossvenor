SELECT COUNT(*) FROM hotel;
SELECT AVG(price) FROM room;

SELECT SUM(price) FROM room WHERE type = 'D';
SELECT COUNT(DISTINCT guest_no)
 FROM booking
 WHERE (date_from >= '2002-08-01' AND date_from <= '2002-08-31');
#Simple Queries
SELECT * FROM hotel;
SELECT * FROM hotel WHERE address LIKE '%London%';
SELECT name, address FROM guest
 WHERE address LIKE '%London%'
ORDER BY name;

SELECT * FROM room
 WHERE price < 40 AND type IN ('Double')
 ORDER BY price;
 SELECT * FROM booking WHERE date_to IS NULL;

 


 

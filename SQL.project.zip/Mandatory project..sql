create database grosvenor;
CREATE TABLE hotel ( hotel_no CHAR(4) NOT NULL, name VARCHAR(20) NOT NULL, address

VARCHAR(50) NOT NULL,primary key(hotel_no));
CREATE TABLE room ( room_no VARCHAR(4) NOT NULL, hotel_no CHAR(4), type CHAR(1)

NOT NULL, price DECIMAL(5,2) NOT NULL, primary key(room_no,hotel_no), foreign key (hotel_no) references hotel(hotel_no));
CREATE TABLE booking (hotel_no CHAR(4) NOT NULL, guest_no CHAR(4) NOT NULL, date_from

DATETIME NOT NULL, date_to DATETIME NULL, room_no CHAR(4) NOT NULL, primary key(hotel_no,guest_no,date_from),foreign key(room_no,hotel_no) references room (room_no,hotel_no),foreign key(guest_no) references guest(guest_no));
CREATE TABLE guest ( guest_no CHAR(4) NOT NULL, name VARCHAR(20) NOT NULL, address

VARCHAR(50) NOT NULL , primary key(guest_no));

INSERT INTO hotel VALUES ('H111', 'Grosvenor Hotel', 'London'); 
INSERT INTO hotel VALUES ('HO12', 'The oberoi', 'London');
INSERT INTO hotel VALUES ('HT02', 'Hotel Tradient', 'Hyderabad');
INSERT INTO hotel VALUES ('HR33', 'Hotel Royal', 'London');
 INSERT INTO hotel VALUES ('PH05', 'Hyatt Regency', 'paris');
 INSERT INTO hotel VALUES ('CM09', 'Marriot', 'Chicago');
 
INSERT INTO room VALUES ('101', 'H111', 'S', 72.00);
INSERT INTO room VALUES ('102', 'HO12', 'D', 89.00);
INSERT INTO room VALUES ('203', 'HT02', 'D', 95.00);
INSERT INTO room VALUES ('404', 'HR33', 'S', 90.00);
INSERT INTO room VALUES ('401', 'HR33', 'D', 88.00);
 INSERT INTO room VALUES ('501', 'PH05', 'S', 92.00);
INSERT INTO room VALUES ('505', 'PH05', 'D', 98.00);
INSERT INTO room VALUES ('1001', 'CM09', 'D', 89.00);

 
INSERT INTO guest VALUES ('G111', 'John Smith', 'London');
INSERT INTO guest VALUES ('HG12', 'Kamal Kaushik', 'Gaziabad');
INSERT INTO guest VALUES ('GJ22', 'Rishita Jha', 'Surat'); 
INSERT INTO guest VALUES ('MJ19', 'Presuni Yumnam', 'Manipur');
 INSERT INTO guest VALUES ('SG78', 'Dilpesh Jain', 'Hyderabad');
 INSERT INTO guest VALUES ('RK23', 'John Doe', 'Lodon'); 
  INSERT INTO guest VALUES ('KV12', 'Elon Travis', 'Paris'); 
  INSERT INTO guest VALUES ('PK17', 'Tomy Murfy', 'Chicago'); 
  
  
  INSERT INTO booking VALUES ('H111', 'G111', DATE'1999-01-01', DATE'1999-01-02', '101');
 INSERT INTO booking VALUES ('HO12', 'HG12', DATE'2000-04-06', DATE'2000-04-12', '102');
 INSERT INTO booking VALUES ('HT02', 'GJ22', DATE'2000-06-01', DATE'2000-06-07', '203');
 INSERT INTO booking VALUES ('CM09', 'MJ19', DATE'2001-02-09', DATE'2001-02-15', '1001');
 INSERT INTO booking VALUES ('HR33', 'SG78', DATE'2002-08-12', DATE'2002-09-02', '401');
 INSERT INTO booking VALUES ('PH05', 'RK23', DATE'2003-05-29', DATE'2003-06-08', '501');
  INSERT INTO booking VALUES ('HR33', 'KV12', DATE'1999-11-23', DATE'1999-11-29', '404');
 INSERT INTO booking VALUES ('PH05', 'PK17', DATE'2005-09-06', DATE'2005-09-18', '505');
 
 UPDATE room SET price = price*1.05;
 
 CREATE TABLE booking_old ( hotel_no CHAR(4) NOT NULL, guest_no CHAR(4) NOT NULL, date_from DATETIME NOT NULL, date_to DATETIME NULL, room_no VARCHAR(4) NOT NULL);
INSERT INTO booking_old (SELECT * FROM booking WHERE date_to < DATE'2000-01-01');
 DELETE FROM booking WHERE date_to < DATE('2000-01-01');


 